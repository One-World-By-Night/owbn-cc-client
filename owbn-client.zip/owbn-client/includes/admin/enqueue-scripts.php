<?php

/**
 * OWBN-Client enqueue scripts
 * location: includes/admin/enqueue-scripts.php
 * @package OWBN-Client
 * @version 2.0.0
 */

defined('ABSPATH') || exit;
