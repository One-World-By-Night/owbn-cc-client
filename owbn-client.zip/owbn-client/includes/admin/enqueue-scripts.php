<?php

/**
 * OWBN-Client enqueue scripts
 * location: includes/admin/enqueue-scripts.php
 * @package OWBN-Client
 * @version 2.1.1
 */

defined('ABSPATH') || exit;
